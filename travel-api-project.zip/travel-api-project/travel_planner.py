import json
import os
import requests
import argparse
from datetime import datetime
from dotenv import load_dotenv
from openai import OpenAI


# .env 파일 불러오기
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
KAKAO_REST_API_KEY = os.getenv("KAKAO_REST_API_KEY", "").strip()

# API 키 확인
if not OPENAI_API_KEY:
    raise ValueError("OPENAI_API_KEY가 .env 파일에 없습니다.")

if not KAKAO_REST_API_KEY:
    raise ValueError("KAKAO_REST_API_KEY가 .env 파일에 없습니다.")


# OpenAI 클라이언트 생성
client = OpenAI(api_key=OPENAI_API_KEY)

def parse_args():
    parser = argparse.ArgumentParser(description="국내 여행 추천 CLI 프로그램")

    parser.add_argument(
        "-date",
        "--date",
        required=True,
        help="여행 날짜를 YYYY-MM-DD 형식으로 입력하세요. 예: 2025-03-15"
    )

    args = parser.parse_args()

    try:
        datetime.strptime(args.date, "%Y-%m-%d")
    except ValueError:
        parser.error("날짜 형식이 올바르지 않습니다. YYYY-MM-DD 형식으로 입력하세요.")

    return args

def get_travel_keywords(city, theme):
    """
    OpenAI API를 사용해서 여행지 검색 키워드를 추천받는 함수
    OpenAI 사용 한도가 없으면 기본 키워드로 대체
    """
    prompt = f"""
    사용자가 {city} 여행을 가려고 합니다.
    여행 테마는 {theme}입니다.

    카카오 장소 검색 API에 넣기 좋은 검색어 3개를 추천해주세요.
    반드시 쉼표로만 구분해서 출력하세요.

    예시:
    부산 맛집, 부산 감성 카페, 부산 해변
    """

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "너는 여행 추천 도우미야."},
                {"role": "user", "content": prompt}
            ]
        )

        result = response.choices[0].message.content
        keywords = [keyword.strip() for keyword in result.split(",")]
        return keywords

    except Exception as e:
        print("\nOpenAI API 호출에 실패했습니다.")
        print("이유:", e)
        print("대신 기본 검색 키워드를 사용합니다.\n")

        return [
    f"{city} {theme}",
    f"{city} 명소",
    f"{city} 카페"
]


def search_place_with_kakao(keyword):
    """
    Kakao Local API를 사용해서 장소를 검색하는 함수
    """
    url = "https://dapi.kakao.com/v2/local/search/keyword.json"

    headers = {
        "Authorization": f"KakaoAK {KAKAO_REST_API_KEY}"
    }

    params = {
        "query": keyword,
        "size": 3
    }

    response = requests.get(url, headers=headers, params=params)

    
    response.raise_for_status()

    data = response.json()
    return data["documents"]


def save_result(content):
    """
    결과를 results 폴더 안에 txt 파일로 저장하는 함수
    """
    os.makedirs("results", exist_ok=True)

    with open("results/travel_plan.txt", "w", encoding="utf-8") as file:
        file.write(content)

def parse_args():
    parser = argparse.ArgumentParser(description="AI 여행 추천 프로그램")

    parser.add_argument(
        "-date",
        "--date",
        required=True,
        help="여행 날짜를 YYYY-MM-DD 형식으로 입력하세요. 예: 2025-03-15"
    )

    args = parser.parse_args()

    try:
        datetime.strptime(args.date, "%Y-%m-%d")
    except ValueError:
        parser.error("날짜 형식이 올바르지 않습니다. YYYY-MM-DD 형식으로 입력하세요.")

    return args

def get_initial_recommendation(client, travel_date):
    prompt = f"""
너는 국내 여행 추천 전문가야.

사용자가 입력한 여행 날짜는 {travel_date}야.
이 날짜에 여행하기 좋은 국내 도시 하나를 추천해줘.

반드시 아래 JSON 형식으로만 답변해줘.
설명 문장, 마크다운 코드블록, 추가 텍스트는 절대 넣지 마.

{{
  "recommended_city": "추천 도시명",
  "weather": "예상 날씨 또는 계절 특징",
  "events": "해당 시기 즐길 만한 행사나 활동",
  "reason": "이 도시를 추천하는 이유"
}}
"""

    for attempt in range(2):  # 총 2번 시도: 최초 1회 + 재시도 1회
        try:
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {
                        "role": "system",
                        "content": "너는 국내 여행지를 추천하는 AI 여행 전문가야."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                response_format={"type": "json_object"}
            )

            content = response.choices[0].message.content
            return json.loads(content)

        except json.JSONDecodeError as e:
            print(f"JSON 파싱 실패: {attempt + 1}번째 시도", e)

            if attempt == 0:
                print("JSON 파싱 재시도 중...")
                continue

        except Exception as e:
            print(f"OpenAI 추천 도시 생성 실패: {attempt + 1}번째 시도", e)

            if attempt == 0:
                print("OpenAI 호출 재시도 중...")
                continue

    return {
        "recommended_city": "부산",
        "weather": "기본 추천",
        "events": "해변 산책, 맛집 탐방",
        "reason": "OpenAI 호출 또는 JSON 파싱 실패 시 기본 도시로 부산을 사용합니다."
    }


def main():
    args = parse_args()
    travel_date = args.date

    print("=== AI 여행 추천 프로그램 ===")
    print(f"입력한 여행 날짜: {travel_date}")

    errors = []
    all_places = []

    print("\nOpenAI가 여행 날짜를 바탕으로 추천 도시를 고르는 중입니다...")

    initial_info = get_initial_recommendation(client, travel_date)

    city = initial_info.get("recommended_city", "부산")
    theme = initial_info.get("theme", "날짜 기반 추천 여행")

    print(f"\n추천 도시: {city}")
    print(f"추천 테마: {theme}")
    print(f"추천 이유: {initial_info.get('reason', '추천 이유 없음')}")

    keywords = [
        f"{city} 맛집",
        f"{city} 명소",
        f"{city} 카페"
    ]

    print("\n추천 검색 키워드:")
    for keyword in keywords:
        print("-", keyword)

    # 여기 아래부터 기존 Kakao 검색 코드 계속 이어서 작성

    final_result = ""

    seen_places = set()
    all_places = []
    
    for keyword in keywords:
        final_result += f"\n# {keyword}\n"

        places = search_place_with_kakao(keyword)

        if not places:
            final_result += "검색 결과가 없습니다.\n\n"
            continue

        for place in places:
            name = place.get("place_name")
            address = place.get("road_address_name") or place.get("address_name")
            phone = place.get("phone")
            url = place.get("place_url")

            unique_key = url if url else f"{name}_{address}"

            if unique_key in seen_places:
                continue

            seen_places.add(unique_key)

            place_data = {
                "keyword": keyword,
                "place_name": name,
                "address": address,
                "phone": phone,
             "url": url
      } 

            all_places.append(place_data)

            final_result += f"- 장소명: {name}\n"
            final_result += f"  주소: {address}\n"
            final_result += f"  전화번호: {phone}\n"
            final_result += f"  링크: {url}\n\n"

    print("\n=== 추천 결과 ===")
    print(final_result)

    save_result(final_result)
    print("결과가 results/travel_plan.txt 파일에 저장되었습니다.")

    save_results_to_json(city, theme, keywords, all_places, errors)

def save_markdown_report(results_data):
    os.makedirs("results", exist_ok=True)

    file_path = "results/travel_report.md"

    with open(file_path, "w", encoding="utf-8") as f:
        f.write("# AI 여행 추천 리포트\n\n")

        f.write("## 1. 추천 도시\n\n")
        f.write(f"- {results_data.get('city', '도시 정보 없음')}\n\n")

        f.write("## 2. 추천 테마\n\n")
        f.write(f"- {results_data.get('theme', '테마 정보 없음')}\n\n")

        f.write("## 3. 추천 검색 키워드\n\n")
        for keyword in results_data.get("recommended_keywords", []):
            f.write(f"- {keyword}\n")
        f.write("\n")

        f.write("## 4. 추천 장소 목록\n\n")

        places = results_data.get("places", [])

        if not places:
         f.write("추천 장소 정보가 없습니다.\n\n")

        else:
         for idx, place in enumerate(places, start=1):
          name = place.get("place_name") or place.get("name") or "이름 없음"
        category = place.get("category_name") or place.get("category") or "분류 없음"
        address = place.get("address_name") or place.get("address") or "주소 없음"
        road_address = place.get("road_address_name") or place.get("road_address") or "도로명 주소 없음"
        phone = place.get("phone") or "전화번호 없음"
        url = place.get("place_url") or place.get("url") or "링크 없음"

        f.write(f"### {idx}. {name}\n\n")
        f.write(f"- 분류: {category}\n")
        f.write(f"- 주소: {address}\n")
        f.write(f"- 도로명 주소: {road_address}\n")
        f.write(f"- 전화번호: {phone}\n")
        f.write(f"- 링크: {url}\n\n")

        errors = results_data.get("errors", [])

        if errors:
            f.write("## 5. 오류 목록\n\n")
            for error in errors:
                f.write(f"- {error}\n")

    print(f"결과가 {file_path} 파일에 저장되었습니다.")

def save_results_to_json(city, theme, keywords, places, errors):
    os.makedirs("results", exist_ok=True)

    results_data = {
        "city": city,
        "theme": theme,
        "recommended_keywords": keywords,
        "places": places,
        "errors": errors
    }

    with open("results/travel_plan.json", "w", encoding="utf-8") as f:
        json.dump(results_data, f, ensure_ascii=False, indent=2)

    print("결과가 results/travel_plan.json 파일에 저장되었습니다.")

    save_markdown_report(results_data)
 
if __name__ == "__main__":
    main()

